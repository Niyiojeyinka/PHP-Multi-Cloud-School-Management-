<div class="w3-padding-large"><br><center>
	<div style="max-width: 450px;height: 300px;background-image: url('<?= base_url(
    'assets/images/profiles/world.png') ?>');background-position: center; " class="w3-card-4 w3-xxpadding w3-margin">
    <div style="max-width: 425px;">
		<div class="w3-margin-top">
		<b><span style="text-shadow:3px 3px silver" class="w3-large w3-block w3-margin-top">Prototype College</span>
		<span class="w3-tiny">Internet HQ ,Mars District Universe</span><br><span class="w3-tiny">07086825489</span></b></div>
<div class="">
	<div class="w3-half">
		<br><br>
		<img style="width:150px;height:150px" src="<?= base_url(
    'assets/images/profiles/prototype.png') ?>" class=""/><br>
    <b class="w3-large w3-margin-top w3-text-themeb">STUDENT</b>
	</div>
	<div class="w3-half w3-padding w3-small">
		<b class="w3-large">Wilson Hills</b><br>
		<span class="w3-medium">XZC3559</span><br><span class="w3-small">
		Senior Secondary School 2(SS2)</span><br>
		Gender : Male<br>

		<img src="https://chart.googleapis.com/chart?chs=100x100&cht=qr&chl=<?=urlencode("http://gettew.com/id/XZC3559") ?>&choe=UTF-8" title="Gettew Card" /><br>
		<span class="w3-tiny">Scan here</span>

	</div>
</div>
	</div>
	</div>

<br><br><br>

<div style="max-width: 450px;height: 300px;background-image: url('<?= base_url(
    'assets/images/profiles/bg.png') ?>');" class="w3-card-4 w3-xxpadding w3-margin">
    <div style="max-width: 425px;height: 275px;" class="w3-padding w3-margin">
    	<ol class="w3-small">
    	<li>This Card remain property of PROTOTYPE COLLEGE</li>
    	<li>This card is not transferable and must be Produced if requested by any officer or staff of PROTOTYPE COLLEGE  </li>
    	<li>This card card must be returned to the School Address if found </li>
    	<li>The Loss of this card must be reported immediately</li>
</ol>
<span class="" style="text-shadow: 1px 1px teal">
By using this card the holder agrees to all the terms and conditions under which it was issued .This card is issued by Prototype College under the licence of Gettew.com</span>
	</div>
	</div>
</center>

</div>