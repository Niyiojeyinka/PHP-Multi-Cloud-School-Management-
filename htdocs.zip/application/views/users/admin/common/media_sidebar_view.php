	<div class="w3-col l3 w3-center">
		<br><br><br><br>
			<div class="w3-margin w3-center">
<br><br>
<b class="w3-medium w3-text-theme w3-margin-top">Media</b><br><br>
<ul>
  <li>Upload Files</li><br>
    <li>Manage Files</li><br>
<a href="<?php echo site_url("gettew_webfunction/manage_media/".$this->uri->segment(3)); ?>" class="w3-button w3-teal w3-hover-white w3-border w3-border-teal w3-hover-text-teal" style="text-decoration: none;">Open Media</a>
</ul>



</div>

</div>
</div>