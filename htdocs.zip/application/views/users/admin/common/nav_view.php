<header style="background-color:rgb(31, 31, 31);position:;" class="w3-bar w3-cell-row w3-padding">
    <b class="w3-large w3-cell w3-left w3-margin-left   w3-text-white">
      <a href="<?= site_url() ?>">Gettew</a></b>


    <div class="w3-right w3-small    w3-text-white"> 
              <a href="<?=site_url("gettew_dashboard/account_settings") ?>"
   class="w3-bar-item w3-margin-left w3-margin-right"
   ><i class="fa fa-user w3-medium"></i></a>

             </div>

</header>
