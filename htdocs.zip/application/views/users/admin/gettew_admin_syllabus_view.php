<div class="w3-container w3-center">

  <br>
  <hr>
  <span class="w3-text-theme w3-xlarge w3-center w3-serif">School Syllabus</span><br>
  <hr>


	


</div>