<div class="w3-padding-large"><br><center>
<img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=<?=urlencode("http://gettew.com/id/".$student_id) ?>&choe=UTF-8" title="Gettew Card" />

<br><br><br>

<div style="max-width: 450px;height: 300px;background-image: url('<?= base_url(
    'assets/images/profiles/bg.png') ?>');" class="w3-card-4 w3-xxpadding w3-margin">
    <div style="max-width: 425px;height: 275px;" class="w3-padding w3-margin">
    	<ol class="w3-small">
    	<li>This Card remain property of PROTOTYPE COLLEGE</li>
    	<li>This card is not transferable and must be Produced if requested by any officer or staff of PROTOTYPE COLLEGE  </li>
    	<li>This card card must be returned to the School Address if found </li>
    	<li>The Loss of this card must be reported immediately</li>
</ol>
<span class="" style="text-shadow: 1px 1px teal">
By using this card the holder agrees to all the terms and conditions under which it was issued .This card is issued by Prototype College under the licence of Gettew.com</span>
	</div>
	</div>
</center>

</div>