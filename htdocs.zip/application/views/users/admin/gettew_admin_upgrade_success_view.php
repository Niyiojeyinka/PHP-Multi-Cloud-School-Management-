<div class="w3-container w3-padding">
<center>
	<i class="fa fa-check-circle w3-jumbo w3-text-green"></i><br>
	<div style="max-width: 80%;" class="w3-text-green w3-padding-jumbo"><strong>Hey,Congratulations Your Account has been Successfully Upgraded and your Software and domain Expires on <?=date("F j Y,g:ia",$school['license_expire']) ?> </strong></div>
<a href="<?=site_url('gettew_dashboard') ?>" class='w3-button w3-teal w3-hover-text-teal w3-hover-white w3-border w3-border-teal'><i class="fa fa-home"></i> Go To Home</a>


</center>

</div>