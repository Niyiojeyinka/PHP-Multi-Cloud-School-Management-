<div class="w3-container w3-margin w3-padding-32 w3-center">
   <div class="w3-container w3-half">

<a href="<?=site_url('parents/pay_fees') ?>"> <div class="w3-card">
      <div class="w3-container w3-padding-32 w3-margin">
       <i class="fa fa-money w3-text-green w3-jumbo"></i>
      <br><span class="w3-small">No ATM Card? Have a Bank Account? you can pay with just your account Number</span>
        <h4>Pay Fees</h4>
      </div>
    </div></a>



<a href="<?=site_url('parents/check_results') ?>"> <div class="w3-card">
      <div class="w3-container w3-padding-32 w3-margin">
       <i class="fa fa-graduation-cap w3-text-blue w3-jumbo"></i>
      <br><span class="w3-small">Check and monitor your child academics performance</span>
        <h4>Check Result</h4>
      </div>
    </div></a>
  </div>


    <div class="w3-container w3-half">


<a href="<?=site_url('parents/manage_payments') ?>"> <div class="w3-card">
      <div class="w3-container w3-padding-32 w3-margin">
       <i class="fa fa-money w3-text-teal w3-jumbo"></i>
      <br><span class="w3-small">View Fees,Download Receipt and more</span>
        <h4>Manage Payments</h4>
      </div>
    </div></a>


<a href="<?=site_url('parents/account_settings') ?>"> <div class="w3-card">
      <div class="w3-container w3-padding-32 w3-margin">
       <i class="fa fa-cogs w3-text-red w3-jumbo"></i>
      <br><span class="w3-small">change mobile number ,change password</span>
        <h4>Account Settings</h4>
      </div>
    </div></a>
  </div>
  </div>
