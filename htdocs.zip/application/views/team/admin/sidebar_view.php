<div class="w3-third w3-white">
<div id="menuc" class="w3-text-white w3-black">
<a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/");?>">Go to Home</a><br>
    <br>
    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("back_controller/index");?>">Admin Home</a><br><br>

    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin/our_users");?>">Schools</a><br><br>

    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin/our_users");?>">ID Card Orders</a><br><br>

    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin/our_users");?>">Result Checkers Orders</a><br><br>

    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin/our_users");?>">Upgrades</a><br><br>

    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin/our_users");?>">CBT Request</a><br><br>

    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin/our_users");?>">Student Payments</a><br><br>


    <a class="w3-text-white w3-padding w3-hover-white" href="<?php echo site_url("/admin/our_users");?>">Messages</a><br><br>

</div>

</div>
