<div style="background-image: url('<?=base_url('assets/images/carryingcard.png') ?>');" class="w3-container w3-padding-jumbo w3-center"><br><br>
<div class="w3-container w3-card-8 w3-center w3-padding">
	



	<span class="w3-xxlarge w3-text-teal">Pricing</span><br>
	<div class="w3-margin w3-padding w3-large">
<div class="w3-half">
	<span>FREE Account Registration</span><br>

<span>Unmeasured Bandwidth</span><br>
		<span>Unmeasured Storage Space</span><br> 
		<span>NGN10,000 per Year</span><br>
		<span>Free Students/Parents Account management</span><br>
<span>Free themes & Templates</span><br>
<br>

</div>
<div class="w3-half">
	<span>NGN600 per Student Digital ID Card</span>
<br>
		<del>NGN100</del> <span>NGN60 Transfer Trasaction Fee</span><br>
		<span>NGN3 per SMS</span><br>
		<span>Free Staff Account management</span><br>
		<span>Free Student Result Management Module*</span><br>
		<span>1% Processed  Payment Withdrawal FEE</span><br>
      <span>NGN50 per Result Checking Scratch Card</span>
</div>
<div class="w3-container ">
	
   <span class="w3-xxlarge w3-text-teal w3-white w3-padding"><strong>Get 50% off your year access fee for the first Year</strong></span><br>
   <span class="w3-xxlarge w3-text-teal w3-white w3-padding"><strong>+ Two-Weeks Free Trial</strong></span><br><strong>+ FREE Result Management Module</strong></span><br>
   <span class="w3-xlarge w3-tag w3-red w3-circle"><b><del>NGN10,000</del></b></span>
   <span class="w3-large">NGN5,000</span>

</div>
	<br>
	<a class="w3-button w3-teal w3-text-white w3-hover-white w3-hover-text-teal w3-border w3-border-teal" href="<?=site_url('register') ?>">Get Started</a>
</div>

	



</div>	

</div>