
<section class="give_margin w3-display-container">

	<div id='imgbox' class="">
	
	<script type="text/javascript">

$('document').ready(
function(){
var slide_1 ='/assets/images/slide1.jpg';
var slide_2 ='/assets/images/slide2.jpg';
var slide_3 ='/assets/images/slide3.jpg';
//var slide_4 ='/assets/images/slide4.jpg';
var slide_5 ='/assets/images/slide5.jpg';
var slide_6 ='/assets/images/slide6.jpg';

var test = [slide_1,slide_2,slide_3/*,slide_4*/,slide_5,slide_6];
setInterval(function(){
var max = test.length ;
var min = 0;
 var i = Math.floor(Math.random() * (max - min) ) + min;

$('#imgx').attr('src',test[i]);
i++;
},10000);

}
);


</script>

	
                <img id='imgx' class="w3-image w3-center" src="<?= base_url("assets/images/slide1.jpg")?>" alt="Slide Show" width="1500" height="1000">


		<div class="w3-margin-left w3-display-left">
			<a href="<?= base_url('Register') ?>" class="w3-button w3-black w3-padding-large w3-hover-white w3-hover-text-theme w3-border w3-border-black">Get Started</a>
			<a href="<?= base_url('login') ?>" class="w3-button w3-teal w3-padding-large w3-hover-white w3-hover-text-theme w3-border w3-border-teal">Sign In</a>
		</div>
	</div>
</section><!--  faceboard ends here  -->

    


<section class="w3-text-grey w3-padding-16 w3-round">
	<center>
<div style="max-width: 90%" class="w3-container">
<div class="w3-row w3-bar w3-margin-top">

<div class="w3-col l5 m5 s12">
	<div class="w3-container w3-margin">
		<b class="w3-xlarge">Create Your School Website.</b>
			<div class="icon w3-third">
				<i class="fa fa-globe w3-text-teal w3-jumbo"></i>
			</div>
			<div class="w3-twothird">
				
				<p  class="w3-medium">Create Beautiful,elegant school Website with Gettew Web builder</p>
								</div>
			</div>
</div>

<div class="w3-col l7 m7 s12">
	<hr>

	<div class="w3-container">
			<div class="w3-margin">
				<i class="fa fa-hand-o-right w3-text-teal w3-large"> Input your school name</i>
			</div><br>
                <div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large"> Choose a Domain or Subdomain for your new school website </i></div><br>
				<div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large"> Submit the necessary data and in few minutes your school website up and running. </i></div>
			
</div>  
<hr>

</div>
		</div>
			<div class="w3-row w3-bar w3-margin-top">

<div class="w3-col l5 m5 s12">
	<div class="w3-container w3-margin">
		<b class="w3-xlarge">Student Result Publishing</b>
			<div class="icon w3-third">
				<i class="fa fa-mortar-board w3-text-teal w3-jumbo"></i>
			</div>
			<div class="w3-twothird">
				
				<p  class="w3-medium">Let Parents/Guardians Monitor their child academics Performance online from anywhere</p>
								</div>
			</div>
</div>


<div class="w3-col l7 m7 s12"><hr>
	<div class="w3-container">
			<div class="w3-margin">
				<i class="fa fa-hand-o-right w3-text-teal w3-large">Easy Management</i>
			</div><br>
                <div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large">
                	Flexible Upload Process
             </i></div><br>
				<div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large"> Auto Publish With Gettew CBT Software</i></div>
			
</div> <hr>   
</div>
		</div>



<div class="w3-row w3-bar w3-margin-top">

<div class="w3-col l5 m5 s12">
	<div class="w3-container w3-margin">
		<b class="w3-xlarge">SMS Communication Tools</b>
			<div class="icon w3-third">
				<i class="fa fa-comments-o w3-text-teal w3-jumbo"></i>
			</div>
			<div class="w3-twothird">
				
				<p  class="w3-medium">Let you send an sms to parent/parent,staff and any other phone number</p>
								</div>
			</div>
</div>


<div class="w3-col l7 m7 s12"><hr>
	<div class="w3-container">
			<div class="w3-margin">
				<i class="fa fa-hand-o-right w3-text-teal w3-large">Send SMS to Parents</i>
			</div><br>
                <div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large">
                	Send SMS to Staff
             </i></div><br>
				<div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large">Make an urgent anouncement with SMS</i></div>
			
</div> <hr>   
</div>
		</div>




<div class="w3-row w3-bar w3-margin-top">

<div class="w3-col l5 m5 s12">
	<div class="w3-container w3-margin">
		<b class="w3-xlarge">Easy Online Payment Facility</b>
			<div class="icon w3-third">
				<i class="fa fa-credit-card w3-text-teal w3-jumbo"></i>
			</div>
			<div class="w3-twothird">
				
				<p  class="w3-medium">Let Parents/Guardians Pay their child's Tuition/school Fee either by scanning thier child's ID Card or in the parent account through the school website</p>
								</div>
			</div>
</div>


<div class="w3-col l7 m7 s12"><hr>
	<div class="w3-container">
			<div class="w3-margin">
				<i class="fa fa-hand-o-right w3-text-teal w3-large">Fast ,Easy and Secure Payment</i>
			</div><br>
                <div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large">
                	Pay with Capture
             </i></div><br>
				<div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large">Fast and Easy Withdrawal Process</i></div>
			
</div> <hr>   
</div>
		</div>

<!--another feature or product --->
	<div class="w3-row w3-bar w3-margin-top">

<div class="w3-col l5 m5 s12">
	<div class="w3-container w3-margin">
		<b class="w3-xlarge">Profile Management</b>
			<div class="icon w3-third">
				<i class="fa fa-user w3-text-teal w3-jumbo"></i>
			</div>
			<div class="w3-twothird">
				
				<p  class="w3-medium">With Gettew,You can also manage both student and Staff profile</p>
								</div>
			</div>
</div>


<div class="w3-col l7 m7 s12">
	<div class="w3-container"><hr>
			<div class="w3-margin">
				<i class="fa fa-hand-o-right w3-text-teal w3-large">Issue Digital Identity Credentials</i>
			</div><br>
                <div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large">
                	Individual Data Management Module
             </i></div><br>
				<div class="w3-margin"><i class="fa fa-hand-o-right w3-text-teal w3-large"> Attendance Management</i></div>
			
</div>   <hr> 
</div>
		</div></div></center>
</section>
 
<div class="qoute w3-padding-large w3-center">
				<i class="w3-text-teal w3-xxlarge">"Make it as simple as possible, but not simpler."<br><i class="fa fa-gavel w3-text-teal w3-xxlarge"></i>
<p class="w3-small">Albert Einstein</p></i>
			</div>
			<center>
			<i>
			<a href="<?= base_url('Register') ?>" class="w3-button w3-black w3-padding-large w3-margin w3-round w3-xlarge w3-hover-white w3-hover-text-theme w3-border w3-border-black">Get Started</a></i></center>
<section class="w3-center">
	<h class="w3-xlarge w3-text-gray"><b>Stil Not Convinced?</b></h>
	<p class="w3-text-gray w3-large">Here are why you should choose gettew: </p>
	<center>
	<div style="overflow-x: scroll;" class="w3-container w3-padding">
		<div class="w3-row">
			<div class="w3-cell w3-padding">
				<i class="fa fa-search-plus w3-text-teal w3-xxlarge"></i>
				<br><p class="w3-text-gray">SEO Friendly</p>
			</div>
			<div class="w3-cell w3-padding"><i class="fa fa-mobile-phone w3-text-teal w3-xxlarge"></i>
				<br><p class="w3-text-gray">Responsive Layouts</p></div>
			<div class="w3-cell w3-padding"><i class="fa fa-location-arrow w3-text-teal w3-xxlarge"></i>
				<br><p class="w3-text-gray">Easy Navigation</p></div>
            <div class="w3-cell w3-padding">
				<i class="fa fa-clock-o w3-text-teal w3-xxlarge"></i>
				<br><p class="w3-text-gray">Ready Made</p>
			</div>

		</div>
<div class="w3-row">
			<div class="w3-cell w3-padding">
				<i class="fa fa-lock w3-text-teal w3-xxlarge"></i>
				<br><p class="w3-text-gray">Great Security</p>
			</div>
			<div class="w3-cell w3-padding"><i class="fa fa-cloud w3-text-teal w3-xxlarge"></i>
				<br><p class="w3-text-gray">99.9% Uptime</p></div>
			<div class="w3-cell w3-padding"><i class="fa fa-dollar w3-text-teal w3-xxlarge"></i>
				<br><p class="w3-text-gray">Cheap Pricing</p></div>

<div class="w3-cell w3-padding">
				<i class="fa fa-line-chart w3-text-teal w3-xxlarge"></i>
				<br><p class="w3-text-gray">Great Performance</p>
			</div>
<img class="w3-image w3-margin" src="<?=base_url('assets/images/payment_power.png') ?>">
			
		</div>



	</div></center>

</section>
